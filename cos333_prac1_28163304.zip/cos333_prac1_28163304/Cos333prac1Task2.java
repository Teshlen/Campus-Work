/*
 * Uteshlen Nadesan 28163304
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//package cos333prac1task2;

import java.io.IOException;

/**
 *
 * @author Teshlen
 */
public class Cos333prac1Task2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
      //  System.out.println("hello there and welcome");
        task2Reader task2 = new task2Reader();
//to run the main for task 2       
         task2.mainRun();
        cos332prac1task3 phi = new cos332prac1task3();
//        phi.placeIntoArrays();
    }
    
}
